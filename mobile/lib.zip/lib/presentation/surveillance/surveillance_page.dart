import 'package:flutter/material.dart';

import '../widgets/custom_app_bar.dart';
import '../widgets/custom_bottom_nav.dart';

class SurveillancePage extends StatelessWidget {
  const SurveillancePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(),
      bottomNavigationBar: const CustomBottomNav(currentIndex: 0),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildHeroMapSection(),
            _buildCurrentConditionSection(),
            _buildTreatmentSuccessCard(),
            _buildLatestAlertSection(),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildHeroMapSection() {
    return Stack(
      children: [
        Container(
          height: 625,
          decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/images/surabaya_map_preview.jpeg'),
              fit: BoxFit.cover,
            ),
          ),
        ),

        Container(height: 625, color: Colors.white.withOpacity(0.12)),

        Positioned(
          top: 24,
          left: 26,
          right: 26,
          child: Row(
            children: const [
              Expanded(
                child: _SummaryCard(label: 'TOTAL AKTIF', value: '1,284'),
              ),
              SizedBox(width: 14),
              Expanded(
                child: _SummaryCard(
                  label: 'KASUS BARU',
                  value: '42',
                  trailing: 'Stabil',
                ),
              ),
            ],
          ),
        ),

        Positioned(
          top: 210,
          left: 26,
          right: 26,
          child: _buildCaseSurveillanceCard(),
        ),
      ],
    );
  }

  static Widget _buildCaseSurveillanceCard() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 22,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: const [
              Expanded(
                child: Text(
                  'Case Surveillance',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF20242A),
                  ),
                ),
              ),
              Text(
                'Lihat Detail',
                style: TextStyle(
                  fontSize: 14,
                  color: Color(0xFF0047B3),
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          Container(
            height: 60,
            padding: const EdgeInsets.symmetric(horizontal: 18),
            decoration: BoxDecoration(
              color: const Color(0xFFE6E8EC),
              borderRadius: BorderRadius.circular(13),
            ),
            child: Row(
              children: const [
                Icon(Icons.search, color: Color(0xFF767B86), size: 26),
                SizedBox(width: 14),
                Text(
                  'Cari Wilayah atau Pasien',
                  style: TextStyle(color: Color(0xFF6F7480), fontSize: 14),
                ),
              ],
            ),
          ),

          const SizedBox(height: 28),
          const Text(
            'Wilayah Paling Terdampak',
            style: TextStyle(
              fontSize: 13,
              color: Color(0xFF555B66),
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 22),

          const _ImpactedAreaRow(
            color: Colors.red,
            region: 'Wilayah Wonokromo',
            cases: '15 Active Cases',
          ),
          SizedBox(height: 22),
          const _ImpactedAreaRow(
            color: Colors.amber,
            region: 'Wilayah Gubeng',
            cases: '5 Active Cases',
          ),

          const SizedBox(height: 28),

          SizedBox(
            width: double.infinity,
            height: 56,
            child: ElevatedButton.icon(
              onPressed: null,
              icon: Icon(Icons.filter_alt_outlined),
              label: Text('Filter Wilayah'),
              style: ButtonStyle(
                backgroundColor: MaterialStatePropertyAll(Color(0xFF0047B3)),
                foregroundColor: MaterialStatePropertyAll(Colors.white),
                elevation: MaterialStatePropertyAll(4),
                shadowColor: MaterialStatePropertyAll(Color(0x660047B3)),
                shape: MaterialStatePropertyAll(
                  RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(12)),
                  ),
                ),
                textStyle: MaterialStatePropertyAll(
                  TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCurrentConditionSection() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(26, 46, 26, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Kondisi Saat Ini',
            style: TextStyle(
              fontSize: 29,
              height: 1.05,
              fontWeight: FontWeight.w900,
              color: Color(0xFF20242A),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Riwayat Informasi kesehatan\nterkini secara real-time',
            style: TextStyle(
              fontSize: 17,
              height: 1.45,
              color: Color(0xFF5B616D),
            ),
          ),
          const SizedBox(height: 34),

          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(32, 28, 32, 26),
            decoration: BoxDecoration(
              color: const Color(0xFFF1F2F5),
              borderRadius: BorderRadius.circular(24),
            ),
            child: Stack(
              children: [
                Positioned(
                  right: -22,
                  bottom: -34,
                  child: Icon(
                    Icons.add,
                    size: 120,
                    color: Colors.grey.withOpacity(0.22),
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    _PillLabel(text: 'PERINGATAN LONJAKAN'),
                    SizedBox(height: 26),
                    Text(
                      'Wilayah Wonokromo',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF20242A),
                      ),
                    ),
                    SizedBox(height: 12),
                    Text(
                      'Terjadi lonjakan kasus dalam periode\nterakhir. Diperlukan tindakan cepat untuk\npelacakan kontak.',
                      style: TextStyle(
                        fontSize: 15,
                        height: 1.5,
                        color: Color(0xFF555B66),
                      ),
                    ),
                    SizedBox(height: 28),
                    Text(
                      'Lakukan Pelacakan  →',
                      style: TextStyle(
                        fontSize: 15,
                        color: Color(0xFF0047B3),
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTreatmentSuccessCard() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(26, 26, 26, 0),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(32, 32, 32, 34),
        decoration: BoxDecoration(
          color: const Color(0xFF0047B3),
          borderRadius: BorderRadius.circular(24),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                _BlueIconBox(),
                Spacer(),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '98%',
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        height: 1,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'KEPATUHAN',
                      style: TextStyle(
                        fontSize: 11,
                        letterSpacing: 2,
                        color: Color(0xFFD8E6FF),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 54),
            const Text(
              'Keberhasilan Pengobatan',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'Kepatuhan pengobatan di seluruh\nSurabaya tetap sangat tinggi bulan ini.',
              style: TextStyle(
                fontSize: 15,
                height: 1.35,
                color: Color(0xFFD8E6FF),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLatestAlertSection() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(26, 34, 26, 0),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(32, 32, 32, 28),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: const Color(0xFFE8EAF0)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.03),
              blurRadius: 16,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text(
              'Peringatan Terbaru',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: Color(0xFF20242A),
              ),
            ),
            SizedBox(height: 28),
            _AlertItem(
              iconBackground: Color(0xFFFFD8A8),
              icon: Icons.priority_high,
              title: 'Klaster Terdeteksi',
              description:
                  'Klaster baru sebanyak 15 pasien gejala\nteridentifikasi di area Pasar Wonokromo.',
              time: '14 menit yang lalu',
            ),
            SizedBox(height: 26),
            _AlertItem(
              iconBackground: Color(0xFFDDE6FF),
              icon: Icons.check_circle_outline,
              title: 'Pasien baru',
              description: 'Terdapat Pasien Baru di Wilayah Gubeng',
              time: '2 Jam yang lalu',
            ),
            SizedBox(height: 26),
            _AlertItem(
              iconBackground: Color(0xFFE0E2E6),
              icon: Icons.access_time,
              title: 'Update Wilayah Paling terdampak',
              description:
                  'Saat ini wonokromo menjadi wilayah yang\npaling terdampak',
              time: '4 Jam yang lalu',
            ),
            SizedBox(height: 30),
            _OutlinedFullButton(text: 'Lihat Semua'),
          ],
        ),
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final String label;
  final String value;
  final String? trailing;

  const _SummaryCard({required this.label, required this.value, this.trailing});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 98,
      padding: const EdgeInsets.fromLTRB(20, 18, 16, 16),
      decoration: BoxDecoration(
        color: const Color(0xFFF5F6F8).withOpacity(0.95),
        borderRadius: BorderRadius.circular(5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              fontSize: 11,
              letterSpacing: 2,
              color: Color(0xFF555B66),
              fontWeight: FontWeight.w800,
            ),
          ),
          const Spacer(),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                value,
                style: const TextStyle(
                  fontSize: 30,
                  height: 1,
                  color: Color(0xFF0047B3),
                  fontWeight: FontWeight.w900,
                ),
              ),
              if (trailing != null) ...[
                const SizedBox(width: 8),
                Padding(
                  padding: const EdgeInsets.only(bottom: 3),
                  child: Text(
                    trailing!,
                    style: const TextStyle(
                      fontSize: 12,
                      color: Color(0xFF0047B3),
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

class _ImpactedAreaRow extends StatelessWidget {
  final Color color;
  final String region;
  final String cases;

  const _ImpactedAreaRow({
    required this.color,
    required this.region,
    required this.cases,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Text(
            region,
            style: const TextStyle(
              fontSize: 15,
              color: Color(0xFF20242A),
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
        Text(
          cases,
          style: const TextStyle(
            fontSize: 13,
            color: Color(0xFF20242A),
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}

class _PillLabel extends StatelessWidget {
  final String text;

  const _PillLabel({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
      decoration: BoxDecoration(
        color: const Color(0xFFFFD8A8),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 10,
          letterSpacing: 2,
          color: Color(0xFF5B3B00),
          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }
}

class _BlueIconBox extends StatelessWidget {
  const _BlueIconBox();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 49,
      height: 49,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.12),
        borderRadius: BorderRadius.circular(14),
      ),
      child: const Icon(Icons.link, color: Colors.white),
    );
  }
}

class _AlertItem extends StatelessWidget {
  final Color iconBackground;
  final IconData icon;
  final String title;
  final String description;
  final String time;

  const _AlertItem({
    required this.iconBackground,
    required this.icon,
    required this.title,
    required this.description,
    required this.time,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 41,
          height: 41,
          decoration: BoxDecoration(
            color: iconBackground,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, size: 18, color: const Color(0xFF1F2937)),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.only(top: 2),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 15,
                    color: Color(0xFF20242A),
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 7),
                Text(
                  description,
                  style: const TextStyle(
                    fontSize: 13,
                    height: 1.5,
                    color: Color(0xFF555B66),
                  ),
                ),
                const SizedBox(height: 9),
                Text(
                  time,
                  style: const TextStyle(
                    fontSize: 11,
                    color: Color(0xFF8A9099),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _OutlinedFullButton extends StatelessWidget {
  final String text;

  const _OutlinedFullButton({required this.text});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 51,
      child: OutlinedButton(
        onPressed: null,
        style: ButtonStyle(
          side: const MaterialStatePropertyAll(
            BorderSide(color: Color(0xFFC7CCD6)),
          ),
          foregroundColor: const MaterialStatePropertyAll(Color(0xFF20242A)),
          shape: const MaterialStatePropertyAll(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(8)),
            ),
          ),
          textStyle: const MaterialStatePropertyAll(
            TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
          ),
        ),
        child: Text(text),
      ),
    );
  }
}
